#include "TXLib.h"

void drawMan(int x, int y, int hp)
{
    if (hp > 0)
    {
        txSetColor(TX_WHITE, 4);
        txSetFillColor(TX_WHITE);
        txCircle(x, y, 10);
        txLine  (x, y, x, y + 40);
        txLine  (x, y + 10, x-10, y + 30);
        txLine  (x, y + 10, x+10, y + 30);
        txLine  (x, y + 40, x-10, y + 60);
        txLine  (x, y + 40, x+10, y + 60);
    }
}

int wallCollision(int y)
{
    if (y < 0)
    {
        y = 0;
    }
    if (y > 500)
    {
        y = 500;
    }

    return y;
}

int moveX(int x, int speed)
{
    if (GetAsyncKeyState(VK_RIGHT))
    {
        x = x + speed;
    }
    if (GetAsyncKeyState(VK_LEFT))
    {
        x = x - speed;
    }

    return x;
}


bool gemCollision(int x, int y, int xGem, int yGem, bool visibleGem)
{
    //���� ����������� � �����������
    if (x - 10 < xGem + 75 &&
        x + 10 > xGem      &&
        y - 10 < yGem + 60 &&
        y + 60 > yGem)
    {
        visibleGem = false;
    }

    return visibleGem;
}

int main()
{
    txCreateWindow (800, 600);

    //����������
    int x = 50;         int y = 300;    int hp = 3; int speed = 10;

    int xVrag = 250;    int yVrag = 500;
    HDC picVrag = txLoadImage ("Platform.bmp");

    int xGem = 600;
    int yGem = 200;
    bool visibleGem = true;
    HDC picGem = txLoadImage("Gem.bmp");

    int xGem2 = 400;
    int yGem2 = 400;
    bool visibleGem2 = true;

    int xGem3 = 500;
    int yGem3 = 400;
    bool visibleGem3 = true;

    int xSpeedZone = 300;   int ySpeedZone = 100;


    //����
    while (x < 700)
    {
        //������� ������
        txSetFillColor(TX_RED);
        txClear();

        txLine(700, 0, 700, 600);


        if (visibleGem)
            txTransparentBlt(txDC(), xGem, yGem, 75, 60, picGem, 0, 0, TX_BLACK);
        if (visibleGem2)
            txTransparentBlt(txDC(), xGem2, yGem2, 75, 60, picGem, 0, 0, TX_BLACK);
        if (visibleGem3)
            txTransparentBlt(txDC(), xGem3, yGem3, 75, 60, picGem, 0, 0, TX_BLACK);

        //����
        txTransparentBlt (txDC(), xVrag, yVrag, 122, 26, picVrag, 0, 0, TX_BLACK);

        //������
        txRectangle(700, 500, 800, 600);
        txDrawText (700, 500, 800, 600, "�������");

        if (txMouseX() > 700 &&
            txMouseX() < 800 &&
            txMouseY() > 500 &&
            txMouseY() < 600)
        {
            visibleGem = true;
            visibleGem2 = true;
            visibleGem3 = true;
        }

        //�
        drawMan(x, y, hp);


        //������� ������
        //������������ � �������
        /*
        if (x - 10 < xGem + 75)
        if (x + 10 > xGem)
        if (y - 10 < yGem + 60)
        if (y + 60 > yGem)
        {
            visibleGem = false;
        }   */
        visibleGem = gemCollision(x, y, xGem, yGem, visibleGem);
        visibleGem2 = gemCollision(x, y, xGem2, yGem2, visibleGem2);
        visibleGem3 = gemCollision(x, y, xGem3, yGem3, visibleGem3);

        //������������ � ����������
        if (x - 10 < xVrag + 122 &&
            x + 10 > xVrag       &&
            y - 10 < yVrag + 26  &&
            y + 60 > yVrag)
        {
            y = yVrag - 60;
        }

        //������������ �� �������
        y = wallCollision(y);

        //if (GetAsyncKeyState('W') && GetAsyncKeyState('A'))
        //��������
        x = moveX(x, speed);

        if (GetAsyncKeyState(VK_UP))
        {
            y = y - 5;
        }
        if (GetAsyncKeyState(VK_DOWN))
        {
            y = y + 5;
        }

        txSleep(30);            //�����
    }


    //��� �������� ������� ���
    txDeleteDC (picVrag);
    txDeleteDC (picGem);

    return 0;
}
